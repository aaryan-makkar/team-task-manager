const express = require("express");
const Task = require("../models/Task");
const authMiddleware = require("../middleware/authMiddleware");
const adminMiddleware = require("../middleware/adminMiddleware");

const router = express.Router();

router.get("/", authMiddleware, async (req, res) => {
    const tasks = await Task.find()
    .populate("assignedTo")
    .populate("projectId");

    res.json(tasks);
});

router.post("/", authMiddleware, adminMiddleware, async (req, res) => {
    const task = await Task.create(req.body);
    res.json(task);
});

router.put("/:id", authMiddleware, async (req, res) => {
    const updatedTask = await Task.findByIdAndUpdate(
        req.params.id,
        req.body,
        { new: true }
    );

    res.json(updatedTask);
});

module.exports = router;