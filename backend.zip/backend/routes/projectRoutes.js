const express = require("express");
const Project = require("../models/Project");
const authMiddleware = require("../middleware/authMiddleware");
const adminMiddleware = require("../middleware/adminMiddleware");

const router = express.Router();

router.get("/", authMiddleware, async (req, res) => {
    const projects = await Project.find();
    res.json(projects);
});

router.post("/", authMiddleware, adminMiddleware, async (req, res) => {
    const project = await Project.create({
        ...req.body,
        createdBy: req.user.id
    });

    res.json(project);
});

module.exports = router;